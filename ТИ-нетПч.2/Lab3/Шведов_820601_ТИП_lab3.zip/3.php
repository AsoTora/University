<?php
echo "<b> Task 3 </b> <br>";

for ($i = 0; $i < 10; print($i++)) {}

