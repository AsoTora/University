<?php
    require_once __DIR__ . '/check.php';
    page_check();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Lab 5 task 1</title>
    <link rel="stylesheet" href="style.css" />
</head>
<h1>Choose page</h1>

<body>
    <ul>
        <li><a href="page1.php">Page 1</a></li>
        <li><a href="page2.php">Page 2</a></li>
    </ul>
</body>

<footer>
    <a href="logout.php">Logout</a>
</footer>

</html>