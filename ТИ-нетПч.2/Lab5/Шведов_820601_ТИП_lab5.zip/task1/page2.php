<?php
require_once __DIR__ . '/check.php';
page_check();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 5 task 1</title>
    <link rel="stylesheet" href="style.css">
</head>

<h1> Page B </h1>

<body>
    <img src="http://2.bp.blogspot.com/-8LkITKIlbo4/TfP8x0m5r5I/AAAAAAAAAA4/eX2aCApBcw0/s640/echo_gras_righ_500wt.jpg">
</body>

<footer>
    <a href="choose.php"> Go to choose Page </a>
    <br>
    <a href="logout.php">Logout</a>
</footer>

</html>