<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <?php
        $line1 = "В своих стихах он скукой дышит,";
        $line2 = "Жужжаньем их наводит сон.";
        $line3 = "Не говорю: зачем он пишет,";
        $line4 = "Но для чего читает он?";
        echo $line1."</br>";
        echo $line2."</br>";
        echo $line3."</br>";
        echo $line4."</br></br>";
        echo "<u>Е.А.Боратынский</u>";
    ?>
</body>
</html>