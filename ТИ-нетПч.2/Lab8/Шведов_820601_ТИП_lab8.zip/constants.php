<?php 
    define('ORIGINAL_DIR', '../../images/original/');
    define('PREVIEW_DIR', '../../images/preview/');
    define('DB_IP', '0.0.0.0:3306');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', 'password');
    define('DB_NAME', 'lab8');
?>