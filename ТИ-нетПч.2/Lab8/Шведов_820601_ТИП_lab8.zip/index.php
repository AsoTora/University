<?php
    header('Location: ./pages/main/view.php');
?>