function res=fun(x);
y1=0.387*x;
res=sqrt(x)-cos(y1);
return