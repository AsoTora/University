clear;
clc;
t=-10:0.1:10;
[x,y]=meshgrid(t,t);
z=fun1(x,y);
mesh(x,y,z);
grid on;
z1=fun1(x,y);
meshc(x,y,z1);
