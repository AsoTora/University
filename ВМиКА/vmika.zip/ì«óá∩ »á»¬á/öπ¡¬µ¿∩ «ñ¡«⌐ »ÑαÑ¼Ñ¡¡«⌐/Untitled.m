clc;
clear;
x=0:0.01:2;
y=fun(x);
plot(x,y,'r.-');
grid on;